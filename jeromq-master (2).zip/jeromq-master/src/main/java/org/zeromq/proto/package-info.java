/**
 * <p>Provides utility classes for ØMQ zproto.</p>
 */
package org.zeromq.proto;
