/**
 * <p>Provides timing utility classes for ØMQ.</p>
 */
package org.zeromq.timer;
