package zmq.util;

public @interface AndroidProblematic
{
}
