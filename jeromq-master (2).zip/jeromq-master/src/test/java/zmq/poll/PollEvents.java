package zmq.poll;

class PollEvents implements IPollEvents
{
    @Override
    public void timerEvent(int id)
    {
    }

    @Override
    public void outEvent()
    {
    }

    @Override
    public void inEvent()
    {
    }

    @Override
    public void connectEvent()
    {
    }

    @Override
    public void acceptEvent()
    {
    }
}
